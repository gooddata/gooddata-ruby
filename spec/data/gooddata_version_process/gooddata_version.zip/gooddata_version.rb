require 'gooddata'

puts "GoodData::VERSION - #{GoodData::VERSION}"
