require 'json'

params = JSON.parse($SCRIPT_PARAMS['data'])
puts params.inspect
