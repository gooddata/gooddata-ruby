require 'json'

puts $SCRIPT_PARAMS.inspect
